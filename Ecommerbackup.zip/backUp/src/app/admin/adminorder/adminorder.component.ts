import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminorder',
  templateUrl: './adminorder.component.html',
  styleUrls: ['./adminorder.component.scss']
})
export class AdminorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
